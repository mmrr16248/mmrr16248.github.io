package register

import (
	// register vfs
	_ "github.com/containers/storage/drivers/vfs"
)
