## containers-storage-delete-container 1 "August 2016"

## NAME
containers-storage delete-container - Delete a container

## SYNOPSIS
**containers-storage** **delete-container** *containerNameOrID*

## DESCRIPTION
Deletes a container and its layer.

## EXAMPLE
**containers-storage delete-container my-awesome-container**

## SEE ALSO
containers-storage-create-container(1)
containers-storage-delete-image(1)
containers-storage-delete-layer(1)
