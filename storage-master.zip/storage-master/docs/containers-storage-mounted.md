## containers-storage-mounted 1 "November 2018"

## NAME
containers-storage mounted - Check if a file system is mounted

## SYNOPSIS
**containers-storage** **mounted** *LayerOrContainerNameOrID*

## DESCRIPTION
Check if a filesystem is mounted

## EXAMPLE
**containers-storage mounted my-container**

## SEE ALSO
containers-storage-mount(1)
containers-storage-unmount(1)
