## containers-storage-images 1 "August 2016"

## NAME
containers-storage images - List known images

## SYNOPSIS
**containers-storage** **images**

## DESCRIPTION
Retrieves information about all known images and lists their IDs and names.

## EXAMPLE
**containers-storage images**

## SEE ALSO
containers-storage-image(1)
