## containers-storage-version 1 "August 2016"

## NAME
containers-storage version - Output version information about the storage library

## SYNOPSIS
**containers-storage** **version**

## DESCRIPTION
Outputs version information about the storage library and *containers-storage*.

## EXAMPLE
**containers-storage version**

## SEE ALSO
containers-storage-status(1)
