## containers-storage-wipe 1 "August 2016"

## NAME
containers-storage wipe - Delete all containers, images, and layers

## SYNOPSIS
**containers-storage** **wipe**

## DESCRIPTION
Deletes all known containers, images, and layers.  Depending on your use case,
use with caution or abandon.

## EXAMPLE
**containers-storage wipe**
