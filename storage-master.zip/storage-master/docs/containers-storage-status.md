## containers-storage-status 1 "August 2016"

## NAME
containers-storage status - Output status information from the storage library's driver

## SYNOPSIS
**containers-storage** **status**

## DESCRIPTION
Queries the storage library's driver for status information.

## EXAMPLE
**containers-storage status**

## SEE ALSO
containers-storage-version(1)
