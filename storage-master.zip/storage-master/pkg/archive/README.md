This code provides helper functions for dealing with archive files.
