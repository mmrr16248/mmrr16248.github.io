// +build windows

package mount

func unmount(target string, flag int) error {
	panic("Not implemented")
}
